export class IndexableTypeTest {

}